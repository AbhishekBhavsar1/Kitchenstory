# Restaurant Project
# REPORT ON THE "TASTY KITCHEN RESTAURANT" WEBSITE


#### By,
[Darshan R](https://www.linkedin.com/in/darshanr27)
<br/> Adichunchanagiri Institute of Technology<br/>
Chikmagalur


## OVERVIEW
The project ‘THE TASTY KITCHEN’ is a restaurant website made using HTML and CSS for customer to get to know about the restaurant.

## GOALS
- Landing page for the restaurant.
- To provide the information about the restaurant.
- To provide the recipe menu list and services provided by the restaurant.
- Directing the website visitors to order the food in food ordering website like zomato.
- Making the website visitors to follow the social media page of the restaurant.

## SPECIFICATIONS
-	We added a logo and navigation bar items for easy use of the website.
-	Added the picture with details of the recipes and the information services provided by restaurant.
-	People can use Contact Us form to give feedback or for any queries.

## TOOLS
- HTML
-	CSS
-	VS CODE
-	GOOGLE FONTS
